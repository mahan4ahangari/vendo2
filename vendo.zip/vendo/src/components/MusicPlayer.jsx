import { useEffect, useRef, useState } from 'react'
import './MusicPlayer.css'

const DURATION = 45
const COVER = 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=160&h=160&q=80'

function formatTime(value) {
  const seconds = Math.max(0, Math.floor(value))
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`
}

function MusicPlayer() {
  const [isOpen, setIsOpen] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [radarActive, setRadarActive] = useState(false)
  const playerRef = useRef(null)

  useEffect(() => {
    if (!isOpen) return undefined
    const closeOnOutsideClick = (event) => {
      if (!playerRef.current?.contains(event.target)) setIsOpen(false)
    }
    const closeOnEscape = (event) => {
      if (event.key === 'Escape') setIsOpen(false)
    }
    document.addEventListener('pointerdown', closeOnOutsideClick)
    document.addEventListener('keydown', closeOnEscape)
    return () => {
      document.removeEventListener('pointerdown', closeOnOutsideClick)
      document.removeEventListener('keydown', closeOnEscape)
    }
  }, [isOpen])

  useEffect(() => {
    if (!isPlaying) return undefined
    let frameId
    let previousFrame
    const advance = (timestamp) => {
      if (previousFrame !== undefined) {
        const elapsed = (timestamp - previousFrame) / 1000
        setCurrentTime((time) => Math.min(DURATION, time + elapsed))
      }
      previousFrame = timestamp
      frameId = window.requestAnimationFrame(advance)
    }
    frameId = window.requestAnimationFrame(advance)
    return () => window.cancelAnimationFrame(frameId)
  }, [isPlaying])

  useEffect(() => {
    if (currentTime >= DURATION) setIsPlaying(false)
  }, [currentTime])

  const progress = (currentTime / DURATION) * 100

  return (
    <div className={`music-player ${isOpen ? 'music-player--open' : ''}`} ref={playerRef}>
      <div
        className={`music-player__island ${isOpen ? 'music-player__island--open' : ''} ${isPlaying ? 'music-player__island--playing' : ''}`}
      >
        <button className="music-player__face" type="button" aria-label="Open music player" aria-expanded={isOpen} onClick={() => setIsOpen((open) => !open)}>
          <img src={COVER} alt="" />
          <span className="music-player__ring" style={{ '--progress': `${progress}%` }} />
        </button>

        <span className="music-player__content" aria-hidden={!isOpen}>
          <span className="music-player__track">
            <img className="music-player__art" src={COVER} alt="" />
            <span className="music-player__details">
              <span className="music-player__title">Glow</span>
              <span className="music-player__artist">Echo</span>
            </span>
          </span>

          <span className="music-player__controls" onClick={(event) => event.stopPropagation()}>
            <span className="music-player__times">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(DURATION - currentTime)}</span>
            </span>
            <input
              className="music-player__seek"
              type="range"
              min="0"
              max={DURATION}
              step="any"
              value={currentTime}
              aria-label="Seek through track"
              style={{ '--progress': `${progress}%` }}
              onChange={(event) => setCurrentTime(Number(event.target.value))}
            />
            <span className="music-player__buttons">
              <button type="button" aria-label="Restart track" onClick={() => setCurrentTime(0)}>
                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1 3v4l6-3.5v3L14 3v10l-7-3.5v3L1 9V3Z" /></svg>
              </button>
              <button className="music-player__play" type="button" aria-label={isPlaying ? 'Pause' : 'Play'} onClick={() => setIsPlaying((playing) => !playing)}>
                {isPlaying ? <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 3h3v10H4zm5 0h3v10H9z" /></svg> : <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 2.7c0-.6.65-.96 1.16-.65l7.4 4.45a1.75 1.75 0 0 1 0 3L5.16 13.95A.75.75 0 0 1 4 13.3z" /></svg>}
              </button>
              <button type="button" aria-label="Restart track" onClick={() => { setCurrentTime(0); setIsPlaying(true) }}>
                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M15 3v4L9 3.5v3L2 3v10l7-3.5v3l6-3.5V3Z" /></svg>
              </button>
              <button className={`music-player__radar ${radarActive ? 'is-active' : ''}`} type="button" aria-label="Toggle radar effect" aria-pressed={radarActive} onClick={() => setRadarActive((active) => !active)}>
                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6.6 1.2A7 7 0 0 1 15 8a.5.5 0 0 1-1 0 6 6 0 1 0-6.5 6v-1a5 5 0 1 1 5.5-5 .5.5 0 0 1-1 0 4 4 0 1 0-4.5 4V11a3 3 0 1 1 3-3 .5.5 0 0 1-1 0 2 2 0 1 0-2.5 1.9v5.6a.5.5 0 0 1-1 0v-.5A7 7 0 0 1 6.6 1.2Z" /></svg>
              </button>
            </span>
          </span>
        </span>
      </div>
    </div>
  )
}

export default MusicPlayer
