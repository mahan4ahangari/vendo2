import './TextEffect.css'

function TextEffect({
  children,
  className = '',
  delay = 0.25,
  stagger = 0.055,
  preset = 'slide',
}) {
  const words = children.trim().split(/\s+/)

  return (
    <p className={`text-effect text-effect--${preset} ${className}`.trim()} aria-label={children}>
      {words.map((word, index) => (
        <span
          className="text-effect-word"
          key={`${word}-${index}`}
          aria-hidden="true"
          style={{ '--word-delay': `${delay + index * stagger}s` }}
        >
          {word}
        </span>
      ))}
    </p>
  )
}

export default TextEffect
