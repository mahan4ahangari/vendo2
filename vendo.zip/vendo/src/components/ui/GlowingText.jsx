import './GlowingText.css'

function GlowingText({
  text,
  className = '',
  color = '#f4fff7',
  glowColor = '#9dffc0',
  fontSize = 'clamp(2.4rem, 7.2vw, 6rem)',
  letterSpacing = '-0.045em',
  lineHeight = 1.02,
  characterStagger = 0.035,
  revealDuration = 0.65,
}) {
  let characterIndex = 0
  const accessibleText = text.replace(/\n/g, ' ')

  return (
    <h1
      className={`glowing-text ${className}`.trim()}
      aria-label={accessibleText}
      style={{
        '--glowing-text-color': color,
        '--glowing-text-glow': glowColor,
        '--glowing-text-font-size': fontSize,
        '--glowing-text-letter-spacing': letterSpacing,
        '--glowing-text-line-height': lineHeight,
        '--glowing-text-duration': `${revealDuration}s`,
      }}
    >
      {text.split('\n').map((line, lineIndex) => (
        <span className="glowing-text-line" key={`line-${lineIndex}`}>
          {Array.from(line).map((character) => {
            const delay = 0.2 + characterIndex * characterStagger
            const key = `char-${characterIndex}`
            characterIndex += 1

            return (
              <span
                className="glowing-text-character"
                key={key}
                aria-hidden="true"
                style={{ '--glowing-text-delay': `${delay}s` }}
              >
                {character === ' ' ? '\u00a0' : character}
              </span>
            )
          })}
        </span>
      ))}
    </h1>
  )
}

export default GlowingText
